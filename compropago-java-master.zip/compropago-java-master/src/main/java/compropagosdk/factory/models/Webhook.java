package compropagosdk.factory.models;


public class Webhook {

    public String id;
    public String url;
    public String mode;
    public String status;
    public String type;

}
