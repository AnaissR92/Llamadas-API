package compropagosdk.factory.models;


public class FeeDetails {

    public double amount;
    public String currency;
    public String type;
    public String application;
    public double amount_refunded;
    public double tax;

}
