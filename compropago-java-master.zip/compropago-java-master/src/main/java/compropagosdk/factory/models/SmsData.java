package compropagosdk.factory.models;


public class SmsData {

    public SmsObject object;

    public SmsData() {
        object = new SmsObject();
    }

}
