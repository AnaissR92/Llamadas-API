package compropagosdk.factory.models;


public class SmsInfo {

    public String type;
    public String Object;
    public SmsData data;

    public SmsInfo() {
        data = new SmsData();
    }

}
