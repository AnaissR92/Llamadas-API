package compropagosdk.factory.models;


public class SmsObject {

    public String id;
    public String Object;
    public String short_id;

}
