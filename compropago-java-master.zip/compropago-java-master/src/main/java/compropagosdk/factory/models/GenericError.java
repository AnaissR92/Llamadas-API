package compropagosdk.factory.models;


public class GenericError {

    public String type;
    public int code;
    public String message;

}
