package compropagosdk.factory.models;

public class Exchange {

    public double rate;
    public long request;
    public String exchange_id;
    public double final_amount;
    public double origin_amount;
    public String final_currency;
    public String origin_currency;

}
