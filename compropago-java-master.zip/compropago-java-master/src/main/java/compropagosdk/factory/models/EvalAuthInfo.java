package compropagosdk.factory.models;


public class EvalAuthInfo {

    public String type;
    public boolean livemode;
    public boolean mode_key;
    public String message;
    public int code;

}
