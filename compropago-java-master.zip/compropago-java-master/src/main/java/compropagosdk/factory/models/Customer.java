package compropagosdk.factory.models;


public class Customer {

    public String customer_name;
    public String customer_email;
    public String customer_phone;

}
